Placeholder download. Replace this zip with your real build and update games.json.
